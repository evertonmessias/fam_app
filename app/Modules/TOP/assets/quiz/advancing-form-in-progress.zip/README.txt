A Pen created at CodePen.io. You can find this one at https://codepen.io/terned/pen/jbRqoL.

 A form that requires answers to move on to the next question. Navigation with arrow keys and return/enter.  Add a question block and see the progress bar update it's size and width (WIP).